If you wish to use this font, contact me by email sutrisno.budiharto@gmail.com. 
Or download myblog http://sutrisno-budiharto.blogspot.com.
For the development of new fonts are expected to have donated funds for the revitalization of the cost of other traditional motifs.
Fund donations can be sent by check to:
BANK: PT Bank Mandiri Tbk Sragen
Account No: 138-00-04848151
Name: Sutrisno BUDIHARTO